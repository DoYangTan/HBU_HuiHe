// 统计代码
var _report = _report || [];
_report.push(['_setAccount', 'webasCTqeakf66g8u']);

(function() {
    var report = document.createElement("script");
    report.src = "https://analysis.huanqiu.com/report.js?id=858d45e1f01f24b9ae02e83792a3ce3c";
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(report, s);
})();

 // 百度统计 
 var _hmt = _hmt || [];
 (function() {
   var hm = document.createElement("script");
   hm.src = "https://hm.baidu.com/hm.js?01f49aa6038f24d8359d90817c9ac427";
   var s = document.getElementsByTagName("script")[0]; 
   s.parentNode.insertBefore(hm, s);
 })();